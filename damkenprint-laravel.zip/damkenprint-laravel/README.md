<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

# Damken Print — Laravel

Nama:Fadhil Zahiruddin Munawwar  
NIM: 20251020034  
Mata Kuliah: Pemrograman Berorientasi Objek  
Pertemuan: 7 — Routing, Controller, Blade  

---

## Tentang Proyek

Damken Print adalah aplikasi web sederhana berbasis Laravel 13 untuk menampilkan katalog produk undangan cetak. Proyek ini dibuat sebagai tugas rumah mata kuliah PBO untuk mempraktikkan konsep MVC (Model-View-Controller) menggunakan Laravel.
