<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BukuController;

Route::get('/dashboard', function () {
    return view('welcome');
});

Route::get('/', function () {
    return 'hallo dek';
});

Route::get('/buku', [BukuController::class, 'index'])->name('buku.index');
Route::get('/buku/{id}', [BukuController::class, 'show'])->name('buku.show');
use App\Http\Controllers\ProdukController;

Route::get('/undangan/{jenis}', [ProdukController::class, 'byKategori'])->name('undangan.kategori');