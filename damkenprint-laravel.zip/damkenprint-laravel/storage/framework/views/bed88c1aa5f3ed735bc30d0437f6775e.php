<h1>Undangan Jenis: <?php echo e($jenis); ?></h1>

<?php if(count($daftarUndangan) === 0): ?>
    <p>Belum ada undangan untuk jenis ini.</p>
<?php else: ?>
    <ul>
        <?php $__currentLoopData = $daftarUndangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $undangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($undangan['nama']); ?> — Rp <?php echo e(number_format($undangan['harga'], 0, ',', '.')); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?> <?php /**PATH C:\laragon\www\damkenprint-laravel\resources\views/produk/kategori.blade.php ENDPATH**/ ?>